
# -*- coding: utf-8 -*-
import psycopg2

# Conecta ao servidor PostgreSQL
conn = psycopg2.connect(
    dbname="nome_do_banco",
    user="seu_usuario",
    password="sua_senha",
    host="10.51.1.198",
    port="7631"
)

# Cria um cursor para executar comandos SQL
cur = conn.cursor()

# Executa um comando SQL para listar todos os bancos de dados
cur.execute("SELECT datname FROM pg_database;")

# Obtém todos os resultados
bancos_de_dados = cur.fetchall()

# Imprime os bancos de dados
print("Bancos de Dados:")
for db in bancos_de_dados:
    print(db[0])

# Fecha o cursor e a conexão
cur.close()
conn.close()