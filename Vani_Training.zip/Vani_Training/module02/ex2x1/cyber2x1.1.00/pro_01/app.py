from flask import Flask, request, render_template
import json
import subprocess

app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        data = request.form['data']
        try:
            cmd = json.loads(data)['command']
            result = execute_command(cmd)
        except Exception as e:
            result = "Error: Invalid input or command"
        return render_template('index.html', result=result)
    return render_template('index.html', result=None)

def execute_command(cmd):
    try:
        process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        output, error = process.communicate()
        if process.returncode == 0:
            if output:
                return output.decode('utf-8')
            else:
                return "Command executed successfully"
        else:
            if error:
                return error.decode('utf-8')
            else:
                return "Error executing command"
    except Exception as e:
        return "Error executing command"

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)