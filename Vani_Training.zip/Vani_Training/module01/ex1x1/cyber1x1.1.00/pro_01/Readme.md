O que é XML External Entity (XXE)?

A Injeção de Entidade Externa XML é muitas vezes referida como uma variante da falsificação de solicitação do lado do servidor (SSRF). O XXE aproveita os analisadores de linguagem que analisam o formato de dados amplamente utilizado, o XML usado em vários cenários comuns, como serviços web SOAP e REST e formatos de arquivo, como PDF, DOCX, HTML.

O problema principal está nos analisadores XML e como, por padrão, eles lidam com chamadas de rede de saída, bem como outros recursos específicos de XML nos quais entraremos. 

Com a vulnerabilidade XXE do mundo real, muitas vezes haverá um grande número de valores de dados no XML enviado, qualquer um dos quais poderá ser usado na resposta do aplicativo inclua o conteúdo do sistema do arquivo:



