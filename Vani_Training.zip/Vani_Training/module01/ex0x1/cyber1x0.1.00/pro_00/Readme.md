Server-Side Template Injection (SSTI): o que é e como remediar
19 de julho de 2023

Com o avanço constante das tecnologias e plataformas web, também temos o surgimento de novas vulnerabilidades e ameaças. Uma dessas ameaças é o Server-Side Template Injection (SSTI), uma vulnerabilidade que pode ser bastante prejudicial se não for devidamente tratada. Neste artigo, vamos entender melhor o que é o SSTI e como remediar essa vulnerabilidade.



