# -*- coding: utf-8 -*-

import socket

def verifica_portas_abertas(ip, porta_inicial, porta_final):
    # Loop através do intervalo de portas
    for porta in range(porta_inicial, porta_final + 1):
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(1)  # Tempo limite de conexão em segundos

        resultado = sock.connect_ex((ip, porta))
        sock.close()

        # Se a conexão for bem-sucedida, a porta está aberta
        if resultado == 0:
            print("A porta {} em {} está aberta.".format(porta, ip))

# IP que você deseja verificar
ip = "10.51.1.198"

# Intervalo de portas a serem verificadas
porta_inicial = 1
porta_final = 10000

# Chamada da função para verificar as portas abertas
verifica_portas_abertas(ip, porta_inicial, porta_final)