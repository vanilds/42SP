Teste 1 

function checkCookie() {
        let username = getCookie("username");
        if (username != "") {
        alert("Welcome again " + username);
        } else {
            username = prompt("Please enter your name:", "");
            if (username != "" && username != null) {
            setCookie("username", username, 365);
            }
        }
        }

        document.write(document.cookie);

///////////////////////////////////////////////////////////////
teste 2

document.write(document.cookie);
        
