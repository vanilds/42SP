#!/bin/sh

# Get the IP address of the container

# Start the application with the IP address and port
echo "Application is running at http://localhost:8000/"

# Start the web server (replace this with the appropriate command to start your web server)
nginx -g "daemon off;"
