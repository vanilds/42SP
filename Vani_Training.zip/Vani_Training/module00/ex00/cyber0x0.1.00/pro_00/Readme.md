Foi idenficicado que existe uma vulnerabilidade quando a pessoa coloca o cookie, sendo possivel verificar o cookie. 

A03:2021-Injeção desliza para a terceira posição. 94% das aplicações foram testadas para alguma forma de injeção, e as 33 CWEs mapeadas nesta categoria têm a segunda maior maioria de ocorrências em aplicações. O Cross-site Scripting agora faz parte desta categoria nesta edição.

Utilizei o [w3](https://www.w3schools.com/js/js_cookies.asp) para resolver a vulnerabilidade