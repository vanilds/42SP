<!DOCTYPE html>
<html>
<head>
    <title>Vulnerable XSS Example</title>
</head>
<body>
    <h1>XSS Vulnerability Example</h1>
    <p>This is a vulnerable page with an XSS vulnerability.</p>
    <form>
        <label for="inputText">Enter some text:</label>
        <input type="text" id="inputText">
        <button type="button" onclick="checkCookie()">Submit</button>
    </form>
    <div id="output"></div>
    <script>

        // Primeiro, criei um arquivo function que armazena o nome do cookie em uma variável:
        // Os parâmetros da função acima são o nome do cookie (cname), o valor do cookie (cvalue) e o número de dias até que o cookie expire (exdays).
        // A função define um cookie adicionando o cookie name, o valor do cookie e a string expires.

      function setCookie(cname = "ftCookies" , cvalue = "If_You_See_Me_Its_Win", exdays) {
        const d = new Date();
        d.setTime(d.getTime() + (exdays*24*60*60*1000));
        let expires = "expires="+d.toUTCString();
        document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
    }

        // Em seguida, criei um function que retorna o valor de um cookie especificado:
        // Tome o cookiename como parâmetro (cname).
        // Crie uma variável (nome) com o texto a ser pesquisado (cname + "=").
        // Decodifique a string do cookie, para lidar com cookies com caracteres especiais, por exemplo, '$'
        // Divida document.cookie em ponto e vírgula em um array chamado ca (ca = decodedCookie.split(';')).
        // Faça um loop pela matriz ca (i = 0; i < ca.length; i++) e leia cada valor c = ca[i]).
        // Se o cookie for encontrado (c.indexOf(name) == 0), retorne o valor do cookie (c.substring(name.length, c.length).
        // Se o cookie não for encontrado, retorne "".

        function getCookie(cname = "ftCookies") {
        let name = cname + "=";
        let decodedCookie = decodeURIComponent(document.cookie);
        let ca = decodedCookie.split(';');
        for(let i = 0; i <ca.length; i++) {
            let c = ca[i];
            while (c.charAt(0) == ' ') {
            c = c.substring(1);
            }
            if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
            }
        }
        return "";
        } 

        //Por último, criamos a função que verifica se um cookie está definido.
        //Se o cookie estiver definido, ele exibirá uma saudação.
        //Se o cookie não estiver definido, ele exibirá uma caixa de prompt solicitando o nome do usuário e armazenará o cookie do nome de usuário por 365 dias, chamando a setCookiefunção:

        function checkCookie() {
        let username = getCookie("username");
        if (username != "") {
        alert("Welcome again " + username);
        } else {
            username = prompt("Please enter your name:", "");
            if (username != "" && username != null) {
            setCookie("username", username, 365);
            }
        }
        }

        document.write(document.cookie);
       
    </script>
    <div id="cookieOutput"></div>
</body>
</html>