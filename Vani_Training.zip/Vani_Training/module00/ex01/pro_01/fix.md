Cross-site Request Forgery (CSRF) é um tipo de ataque de websites maliciosos. Um ataque CSRF às vezes é chamado de ataque de um clique ou transporte de sessão. Esse tipo de ataque envia solicitações desautorizadas de um usuário no qual o website confia.

CSRF utiliza a confiança que um site tenha no navegador de um usuário autenticado para ataques maliciosos. CSRF utiliza links ou scripts para enviar solicitações de HTTP involuntárias para um site de destino onde o usuário está autenticado. A menos que sejam tomadas precauções, as páginas de gerenciamento do WebSEAL, como /pkmslogout, estão suscetíveis a um ataque CSRF. Por exemplo, um intruso pode obter um usuário autenticado do WebSEAL, efetuar logout, obtendo seus navegadores para seguir um link para /pkmslogout.

Você pode configurar o WebSEAL para ajudar a minimizar esse tipo de vulnerabilidade.

    Validação do token secreto
    É possível configurar o WebSEAL para requerer que determinadas solicitações de operação de gerenciamento incluam um token secreto. O WebSEAL utiliza o token secreto na solicitação recebida para validar sua autenticidade.
    Validação do referenciador
    Para ajudar a mitigar ataques de CSRF, é possível configurar o WebSEAL para validar o cabeçalho referer em solicitações HTTP recebidas. O WebSEAL compara esse cabeçalho referer com uma lista de allowed-referers configurada para determinar se a solicitação é válida.
    Rejeitar solicitações de autenticação não solicitadas
    Para mitigação extra contra falsificação de solicitação entre sites (CSRF), é possível configurar o WebSEAL para rejeitar quaisquer solicitações de login não solicitadas. Esta configuração assegura que o WebSEAL não processe solicitações de login sem primeiro emitir um formulário de login.