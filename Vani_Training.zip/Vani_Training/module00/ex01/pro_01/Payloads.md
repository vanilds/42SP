Teste 1 

Pelo terminal é possivel validar a retirada de um valor de $500 utilizando o curl

curl -X POST \
     -H 'Content-Type: application/x-www-form-urlencoded' \
     -d "amount=500" \
     http://localhost:8080/transfer


///////////////////////////////////////////////////////////////
teste 2

Pelo terminal é possivel validar a retirada de um valor de $1000 utilizando o curl

curl -X POST \
     -H 'Content-Type: application/x-www-form-urlencoded' \
     -d "amount=1000" \
     http://localhost:8080/transfer


        
