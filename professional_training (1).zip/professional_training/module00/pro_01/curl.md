curl -X POST \
-H 'Content-Type: multipart/form-data;' \
-d 'amount:1000' \
http://localhost:8080/transfer
